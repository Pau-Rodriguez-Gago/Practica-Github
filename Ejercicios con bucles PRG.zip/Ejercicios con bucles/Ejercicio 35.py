#35. Programa que al introducir un número por teclado permita mostrar ese número de veces tu 
#nombre
repeticiones=int(input("Introduce las veces que quieres que se repita tu nombre: "))
for x in range(repeticiones):
    print("Pau Rodríguez Gago")