#42. Imprima el siguiente patrón con el ciclo for.
contador=0
for x in range (0,5):
  print("*"*x)
for i in range (5,0,-1):
  print("*"*i)