#50. Realiza un programa que de los buenos días 3 veces. Con While
contador=3
while not(contador==0):
    print("Buenos días")
    contador=contador-1